'use client'

import { useCallback, useState } from 'react'
import { SubscriptionModal } from './subscription-modal'
import { AuthModal, type AuthView } from './auth-modal'
import { cn } from '@/lib/utils'
import { ACCENT_THEMES, type AccentThemeId } from '@/lib/accent-themes'
import { Sidebar, type StudioTab } from './sidebar'
import { ChatEngine } from './chat-engine'
import { VideoStudio } from './video-studio'
import { GpsSearch } from './gps-search'

export function StudioHub() {
  const [activeTab, setActiveTab] = useState<StudioTab>('chat')
  const [accent, setAccent] = useState<AccentThemeId>('gold')
  const [temporaryChat, setTemporaryChat] = useState(false)
  const [tiersOpen, setTiersOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const [authView, setAuthView] = useState<AuthView>('signup')

  const openTiers = useCallback(() => setTiersOpen(true), [])
  const closeTiers = useCallback(() => setTiersOpen(false), [])
  const openAuth = useCallback(() => setAuthOpen(true), [])
  const closeAuth = useCallback(() => setAuthOpen(false), [])

  function handleAccentChange(id: AccentThemeId) {
    const theme = ACCENT_THEMES.find((t) => t.id === id)
    if (!theme) return
    const root = document.documentElement.style
    root.setProperty('--neon', theme.color)
    root.setProperty('--neon-foreground', theme.foreground)
    setAccent(id)
  }

  return (
    <div className="flex min-h-dvh bg-background">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        accent={accent}
        onAccentChange={handleAccentChange}
        temporaryChat={temporaryChat}
        onTemporaryChatChange={setTemporaryChat}
        onOpenTiers={openTiers}
        onOpenAuth={openAuth}
      />
      <SubscriptionModal open={tiersOpen} onClose={closeTiers} email="you@phylia.dev" />
      <AuthModal open={authOpen} view={authView} onViewChange={setAuthView} onClose={closeAuth} />
      <main className="relative flex min-w-0 flex-1 flex-col">
        <section
          id="panel-chat"
          role="tabpanel"
          aria-labelledby="tab-chat"
          hidden={activeTab !== 'chat'}
          className={cn(
            'flex h-dvh flex-col',
            activeTab === 'chat' && 'animate-in fade-in slide-in-from-bottom-2 duration-300',
          )}
        >
          <ChatEngine temporaryChat={temporaryChat} />
        </section>
        <section
          id="panel-video"
          role="tabpanel"
          aria-labelledby="tab-video"
          hidden={activeTab !== 'video'}
          className={cn(
            'min-h-dvh',
            activeTab === 'video' && 'animate-in fade-in slide-in-from-bottom-2 duration-300',
          )}
        >
          <VideoStudio />
        </section>
        {activeTab === 'gps' && (
          <section
            id="panel-gps"
            role="tabpanel"
            aria-labelledby="tab-gps"
            className="animate-in fade-in slide-in-from-bottom-2 flex h-dvh flex-col duration-300"
          >
            <GpsSearch />
          </section>
        )}
      </main>
    </div>
  )
}
